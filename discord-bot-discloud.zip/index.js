import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { Client, Collection, GatewayIntentBits, Events, Partials } from 'discord.js';
import config from './config.json' assert { type: 'json' };

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Token desde variable de entorno
const token = process.env.TOKEN;
if (!token) {
  console.error('❌ Debes poner tu token como variable de entorno TOKEN en Discloud.');
  process.exit(1);
}

// Cliente con intents necesarios para bienvenidas y comandos
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ],
  partials: [Partials.User, Partials.GuildMember]
});

client.commands = new Collection();

async function loadCommands() {
  const commandsPath = path.join(__dirname, 'commands');
  const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
  for (const file of commandFiles) {
    const command = await import(`./commands/${file}`);
    if (command?.default?.name) {
      client.commands.set(command.default.name, command.default);
    }
  }
}

async function loadEvents() {
  const eventsPath = path.join(__dirname, 'events');
  const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
  for (const file of eventFiles) {
    const eventModule = await import(`./events/${file}`);
    const event = eventModule.default;
    if (event?.once) {
      client.once(event.name, (...args) => event.execute(client, ...args, config));
    } else {
      client.on(event.name, (...args) => event.execute(client, ...args, config));
    }
  }
}

// Sistema de comandos
client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot || !message.guild) return;

  const prefix = config.prefix;
  if (!message.content.startsWith(prefix)) return;

  const args = message.content.slice(prefix.length).trim().split(/\s+/);
  const commandName = args.shift().toLowerCase();
  const command = client.commands.get(commandName);

  if (!command) return;

  try {
    await command.execute({ client, message, args, config });
  } catch (err) {
    console.error(err);
    message.reply('❌ Ocurrió un error al ejecutar el comando.');
  }
});

// Detección de videos de YouTube
client.on(Events.MessageCreate, async (message) => {
  if (
    !message.author.bot &&
    message.guild &&
    config.inputChannelId &&
    config.outputChannelId &&
    config.notifyRoleId &&
    message.channel.id === config.inputChannelId
  ) {
    const match = message.content.match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
    if (match) {
      const videoURL = match[0];
      try {
        const outputChannel = await client.channels.fetch(config.outputChannelId);
        await outputChannel.send(
          `✨ **¡Atención <@&${config.notifyRoleId}>!** ✨\n\n` +
          `📢 **Nuevo video disponible en YouTube** 🎥🔥\n` +
          `➡️ **Míralo aquí:** ${videoURL}\n\n` +
          `💬 ¡No olvides dejar tu like y comentar qué te pareció! ❤️`
        );
        console.log(`📢 Video enviado a ${outputChannel.name}`);
      } catch (err) {
        console.error("❌ Error al enviar el mensaje:", err);
      }
    }
  }
});

(async () => {
  await loadCommands();
  await loadEvents();
  client.login(token);
})();