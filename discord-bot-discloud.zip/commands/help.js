export default {
  name: 'help',
  description: 'Lista de comandos disponibles',
  async execute({ message, client }) {
    const comandos = Array.from(client.commands.keys())
      .map(cmd => `\`${cmd}\``)
      .join(', ');

    await message.reply({
      content: `📜 **Lista de comandos disponibles:**\n${comandos}`
    });
  }
};