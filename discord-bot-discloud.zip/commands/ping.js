export default {
  name: 'ping',
  description: 'Muestra la latencia del bot',
  async execute({ message }) {
    const sent = await message.reply('Pong...');
    const diff = sent.createdTimestamp - message.createdTimestamp;
    await sent.edit(`🏓 Pong! Latencia: ${diff}ms`);
  }
};