import { EmbedBuilder } from 'discord.js';
export default {
  name: 'guildMemberAdd',
  async execute(client, member, config) {
    if (config.autoroleId && config.autoroleId !== '1405312864289296475') {
      const role = member.guild.roles.cache.get(config.autoroleId);
      if (role) await member.roles.add(role).catch(() => {});
    }
    if (config.welcomeChannelId && config.welcomeChannelId !== '1397288984974983241') {
      const channel = member.guild.channels.cache.get(config.welcomeChannelId);
      if (channel && channel.isTextBased()) {
        const embed = new EmbedBuilder()
          .setTitle('👋 ¡Bienvenid@!')
          .setDescription(`Hola ${member}, disfruta tu estadía en **${member.guild.name}**.`)
          .setColor(config.embedColor || '#2b2d31');
        await channel.send({ embeds: [embed] });
      }
    }
  }
};