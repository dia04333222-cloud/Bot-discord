import { EmbedBuilder } from 'discord.js';
export default {
  name: 'guildMemberRemove',
  async execute(client, member, config) {
    if (config.leaveChannelId && config.leaveChannelId !== '1397288984974983242') {
      const channel = member.guild.channels.cache.get(config.leaveChannelId);
      if (channel && channel.isTextBased()) {
        const embed = new EmbedBuilder()
          .setTitle('👋 Despedida')
          .setDescription(`${member.user?.tag || 'Un miembro'} ha salido de **${member.guild.name}**.`)
          .setColor(config.embedColor || '#2b2d31');
        await channel.send({ embeds: [embed] });
      }
    }
  }
};