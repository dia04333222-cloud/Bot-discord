export default {
  name: 'ready',
  once: true,
  execute(client) {
    console.log(`✅ Conectado como ${client.user.tag}`);
    client.user.setActivity('Listo para ayudar ✨');
  }
};